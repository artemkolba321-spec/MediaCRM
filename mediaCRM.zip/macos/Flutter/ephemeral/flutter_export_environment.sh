#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/home/artem/flutter"
export "FLUTTER_APPLICATION_PATH=/home/artem/my_dir/projects/Mix/mediaCRM"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=/home/artem/my_dir/projects/Mix/mediaCRM/macos/Flutter/ephemeral/Packages/.packages/FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=2.0.0"
export "FLUTTER_BUILD_NUMBER=2"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
