// Supabase Edge Function: platform-oauth-callback
// Handles OAuth callback from platforms and exchanges the code for tokens.
// Tokens are stored in platform_channels.platform_token.
//
// Accepts both:
//   GET  /functions/v1/platform-oauth-callback?code=...&state=...&error=...
//   POST /functions/v1/platform-oauth-callback { "code": "...", "state": "..." }

import { serve } from "https://deno.land/std@0.208.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const GOOGLE_CLIENT_ID = Deno.env.get("GOOGLE_CLIENT_ID") ?? "";
const GOOGLE_CLIENT_SECRET = Deno.env.get("GOOGLE_CLIENT_SECRET") ?? "";
const VK_CLIENT_ID = Deno.env.get("VK_CLIENT_ID") ?? "";
const VK_CLIENT_SECRET = Deno.env.get("VK_CLIENT_SECRET") ?? "";
const GITHUB_CLIENT_ID = Deno.env.get("GITHUB_CLIENT_ID") ?? "";
const GITHUB_CLIENT_SECRET = Deno.env.get("GITHUB_CLIENT_SECRET") ?? "";
const APP_REDIRECT = Deno.env.get("APP_REDIRECT_URL") ?? "mediacrm://oauth-callback";

serve(async (req) => {
  try {
    // ── Parse code + state from GET query params or POST JSON body ──────────
    let code: string | null = null;
    let state: string | null = null;
    let error: string | null = null;

    if (req.method === "GET") {
      const url = new URL(req.url);
      code = url.searchParams.get("code");
      state = url.searchParams.get("state");
      error = url.searchParams.get("error");
    } else {
      const body = await req.json();
      code = body?.code ?? null;
      state = body?.state ?? null;
      error = body?.error ?? null;
    }

    // ── Handle OAuth errors from the provider ──────────────────────────────
    if (error) {
      const desc = new URLSearchParams({ status: "error", message: error });
      const redirectUrl = `${APP_REDIRECT}?${desc}`;
      return Response.redirect(redirectUrl, 302);
    }

    if (!code || !state) {
      const redirectUrl = `${APP_REDIRECT}?status=error&message=${encodeURIComponent("code and state are required")}`;
      return new Response(
        JSON.stringify({ ok: false, message: "code and state are required" }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      );
    }

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE);

    // ── Validate state: channel_id:timestamp ───────────────────────────────
    // State format: "<channel_id>:<unix_ms>"
    const colonIndex = state.lastIndexOf(":");
    if (colonIndex < 1) {
      const redirectUrl = `${APP_REDIRECT}?status=error&message=${encodeURIComponent("Invalid state parameter")}`;
      return new Response(
        JSON.stringify({ ok: false, message: "Invalid state parameter" }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      );
    }

    const channelId = state.slice(0, colonIndex);
    const stateTimestamp = parseInt(state.slice(colonIndex + 1), 10);

    // Guard against expired / reused state (tolerance: 24 hours)
    const now = Date.now();
    if (isNaN(stateTimestamp) || (now - stateTimestamp) > 24 * 60 * 60 * 1000) {
      const redirectUrl = `${APP_REDIRECT}?status=error&message=${encodeURIComponent("State expired or invalid")}`;
      return new Response(
        JSON.stringify({ ok: false, message: "State expired or invalid" }),
        { status: 400, headers: { "Content-Type": "application/json" } }
      );
    }

    // ── Get channel info to know which platform ────────────────────────────
    const { data: channel, error: channelError } = await supabase
      .from("platform_channels")
      .select("platform, user_id")
      .eq("id", channelId)
      .single();

    if (channelError || !channel) {
      const errMsg =
        "Запись площадки не найдена. Это могло произойти, если запись " +
        "была удалена во время OAuth-сессии. OAuth-сессия безопасна: " +
        "токены не сохранены.";
      const redirectUrl = `${APP_REDIRECT}?status=error&message=${encodeURIComponent(errMsg)}`;
      return new Response(
        JSON.stringify({ ok: false, message: errMsg }),
        { status: 404, headers: { "Content-Type": "application/json" } }
      );
    }

    let token: string = "";
    let refreshToken: string | null = null;
    let expiresAt: string | null = null;
    let platformId: string = "";

    switch (channel.platform) {
      case "youtube": {
        const ytResult = await exchangeYouTubeToken(code);
        token = ytResult.accessToken;
        refreshToken = ytResult.refreshToken ?? null;
        expiresAt = ytResult.expiresAt ?? null;
        platformId = await getYouTubeChannelId(token);
        break;
      }
      case "vk": {
        const vkResult = await exchangeVKToken(code);
        token = vkResult.accessToken;
        platformId = vkResult.userId.toString();
        break;
      }
      case "github": {
        const ghResult = await exchangeGitHubToken(code);
        token = ghResult.accessToken;
        platformId = ghResult.login;
        break;
      }
      default:
        const redirectUrl = `${APP_REDIRECT}?status=error&message=${encodeURIComponent(`OAuth callback not supported for: ${channel.platform}`)}`;
        return new Response(
          JSON.stringify({ ok: false, message: `OAuth callback not supported for: ${channel.platform}` }),
          { status: 400, headers: { "Content-Type": "application/json" } }
        );
    }

    // ── Update channel with basic info (tokens go to oauth_tokens table) ────
    const channelUpdateData: Record<string, unknown> = {
      platform_token: token,
      platform_id: platformId,
      has_credentials: true,
      status: "connected",
      auth_method: "oauth",
      error: null,
      last_sync_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    await supabase
      .from("platform_channels")
      .update(channelUpdateData)
      .eq("id", channelId);

    // ── Store OAuth tokens in secure table (not visible to client) ─────────
    const tokenData: Record<string, unknown> = {
      channel_id: channelId,
      user_id: channel.user_id,
      platform: channel.platform,
      access_token: token,
      updated_at: new Date().toISOString(),
    };

    if (refreshToken) {
      tokenData.refresh_token = refreshToken;
    }
    if (expiresAt) {
      tokenData.oauth_expires_at = expiresAt;
    }

    await supabase
      .from("oauth_tokens")
      .upsert(tokenData, { onConflict: "channel_id" });

    // ── Redirect back to app on success ────────────────────────────────────
    const redirectUrl = `${APP_REDIRECT}?status=success&channel_id=${encodeURIComponent(channelId)}`;
    return Response.redirect(redirectUrl, 302);
  } catch (error) {
    console.error("OAuth callback error:", error);
    const errMsg = (error as Error).message || "Unknown error";
    const redirectUrl = `${APP_REDIRECT}?status=error&message=${encodeURIComponent(errMsg)}`;
    return Response.redirect(redirectUrl, 302);
  }
});

// ── Token exchange helpers ────────────────────────────────────────────────────

async function exchangeYouTubeToken(code: string): Promise<{
  accessToken: string;
  refreshToken?: string | null;
  expiresAt?: string | null;
}> {
  const redirectUri = `${SUPABASE_URL}/functions/v1/platform-oauth-callback`;

  const resp = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      code,
      client_id: GOOGLE_CLIENT_ID,
      client_secret: GOOGLE_CLIENT_SECRET,
      redirect_uri: redirectUri,
      grant_type: "authorization_code",
    }),
  });

  const data = await resp.json();

  if (!data.access_token) {
    const errMsg = data.error_description || data.error || "Failed to exchange YouTube token";
    throw new Error(errMsg);
  }

  return {
    accessToken: data.access_token,
    refreshToken: data.refresh_token ?? undefined,
    expiresAt: data.expires_in
      ? new Date(Date.now() + data.expires_in * 1000).toISOString()
      : undefined,
  };
}

async function getYouTubeChannelId(accessToken: string): Promise<string> {
  const resp = await fetch(
    "https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true",
    {
      headers: { Authorization: `Bearer ${accessToken}` },
    }
  );
  const data = await resp.json();
  if (data.items && data.items.length > 0) {
    return data.items[0].id;
  }
  throw new Error("Could not find YouTube channel");
}

async function exchangeVKToken(code: string): Promise<{
  accessToken: string;
  userId: number;
}> {
  const redirectUri = `${SUPABASE_URL}/functions/v1/platform-oauth-callback`;

  const resp = await fetch("https://oauth.vk.com/access_token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: VK_CLIENT_ID,
      client_secret: VK_CLIENT_SECRET,
      redirect_uri: redirectUri,
      code,
      grant_type: "authorization_code",
    }),
  });
  const data = await resp.json();
  if (!data.access_token) {
    throw new Error("Failed to exchange VK token");
  }
  return { accessToken: data.access_token, userId: data.user_id };
}

async function exchangeGitHubToken(code: string): Promise<{
  accessToken: string;
  login: string;
}> {
  const redirectUri = `${SUPABASE_URL}/functions/v1/platform-oauth-callback`;

  const resp = await fetch("https://github.com/login/oauth/access_token", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({
      client_id: GITHUB_CLIENT_ID,
      client_secret: GITHUB_CLIENT_SECRET,
      code,
      redirect_uri: redirectUri,
    }),
  });
  const data = await resp.json();
  if (!data.access_token) {
    throw new Error("Failed to exchange GitHub token");
  }
  const userResp = await fetch("https://api.github.com/user", {
    headers: { Authorization: `Bearer ${data.access_token}` },
  });
  const userData = await userResp.json();
  return { accessToken: data.access_token, login: userData.login };
}
